package com.godsend.controller;

import com.godsend.dto.AllGroupDetailResponseDTO;
import com.godsend.dto.GroupCreationRequestDTO;
import com.godsend.dto.UserGroupDetailResponseDTO;
import com.godsend.dto.MessageResponseDTO;
import com.godsend.service.GroupService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:4200", methods= {RequestMethod.GET, RequestMethod.POST})
@RequestMapping("/godsend/group")
public class GroupController {

    @Autowired
    private GroupService groupService;

    @PostMapping("/create")
    public ResponseEntity<?> createGroup(@RequestBody GroupCreationRequestDTO requestDTO) {
        groupService.createGroup(requestDTO);
        return ResponseEntity.ok(new MessageResponseDTO("Group created successfully"));
    }
    
    @GetMapping("/{userGroupId}")
    public ResponseEntity<UserGroupDetailResponseDTO> getGroupById(@PathVariable Long userGroupId) {
        UserGroupDetailResponseDTO groupDetail = groupService.getGroupById(userGroupId);
        return ResponseEntity.ok(groupDetail);
    }
    
    @GetMapping("/groups")
    public ResponseEntity<List<AllGroupDetailResponseDTO>> getAllGroups() {
        List<AllGroupDetailResponseDTO> groups = groupService.getAllGroups();
        return ResponseEntity.ok(groups);
    }
    
}
