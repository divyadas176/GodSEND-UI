package com.godsend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.godsend.dto.AddUserToGroupRequestDTO;
import com.godsend.dto.GroupMemberResponseDTO;
import com.godsend.service.GroupMemberService;


@RestController
@CrossOrigin(origins = "http://localhost:4200", methods= {RequestMethod.GET, RequestMethod.POST})
@RequestMapping("/godsend/groups")
public class GroupMemberController {

    @Autowired
    private GroupMemberService groupMemberService;

    @PostMapping("/{id}/add")
    public ResponseEntity<String> addUserToGroup(@PathVariable("id") Long userGroupId, @RequestBody AddUserToGroupRequestDTO addUserToGroupRequestDTO) {
    	
        boolean success = groupMemberService.addUserToGroup(userGroupId, addUserToGroupRequestDTO.getUserId(), addUserToGroupRequestDTO.getJoinedDate());
        if (success) {
            return ResponseEntity.ok("User successfully added to the group.");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to add user to the group.");
        }
    }
    
    @GetMapping("/{id}/members")
    public ResponseEntity<List<GroupMemberResponseDTO>> getGroupMembers(@PathVariable("id") Long userGroupId) {
        List<GroupMemberResponseDTO> members = groupMemberService.getGroupMembers(userGroupId);
        if (members.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(members);
        } else {
            return ResponseEntity.ok(members);
        }
    }
}
