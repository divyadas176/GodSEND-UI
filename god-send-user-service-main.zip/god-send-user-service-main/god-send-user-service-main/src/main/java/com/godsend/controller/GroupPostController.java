package com.godsend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.godsend.dto.GroupPostRequestDTO;
import com.godsend.dto.MessageResponseDTO;
import com.godsend.service.GroupPostService;


@RestController
@CrossOrigin(origins = "http://localhost:4200", methods= {RequestMethod.GET, RequestMethod.POST})
@RequestMapping("/godsend/groups")
public class GroupPostController {

    @Autowired
    private GroupPostService groupPostService;

    @PostMapping("/{groupId}/posts")
    public ResponseEntity<MessageResponseDTO> createGroupPost(@PathVariable Long groupId, @RequestBody GroupPostRequestDTO request) {
        // Override the groupId in the request with the path variable
        request.setUserGroupId(groupId);
        groupPostService.createGroupPost(request);
        return ResponseEntity.ok(new MessageResponseDTO("Posted successfully into the group"));
    }
}
