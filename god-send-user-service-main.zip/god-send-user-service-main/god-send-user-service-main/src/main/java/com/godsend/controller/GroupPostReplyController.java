package com.godsend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.godsend.dto.GroupPostReplyRequestDTO;
import com.godsend.dto.MessageResponseDTO;
import com.godsend.service.GroupPostReplyService;


@RestController
@RequestMapping("/godsend/groups")
@CrossOrigin(origins = "http://localhost:4200", methods= {RequestMethod.GET, RequestMethod.POST})
public class GroupPostReplyController {

    @Autowired
    private GroupPostReplyService groupPostReplyService;

    @PostMapping("/post/{groupPostId}/reply")
    public ResponseEntity<MessageResponseDTO> createGroupPost(@PathVariable Long groupPostId, @RequestBody GroupPostReplyRequestDTO request) {
        // Override the groupId in the request with the path variable
        request.setUserGroupPostId(groupPostId);
        groupPostReplyService.createGroupPostReply(request);
        return ResponseEntity.ok(new MessageResponseDTO("Replied successfully for the post"));
    }
}
