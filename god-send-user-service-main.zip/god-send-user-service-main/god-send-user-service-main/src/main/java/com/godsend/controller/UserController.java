package com.godsend.controller;

import com.godsend.dto.AuthenticateUserRequestDTO;
import com.godsend.dto.AuthenticateUserResponseDTO;
import com.godsend.dto.RegisterUserRequestDTO;
import com.godsend.dto.RegisterUserResponseDTO;
import com.godsend.dto.UserGroupsResponseDTO;
import com.godsend.service.GroupMemberService;
import com.godsend.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@CrossOrigin(origins = "http://localhost:4200", methods= {RequestMethod.GET, RequestMethod.POST})
@RequestMapping("/godsend/users")
public class UserController {

    @Autowired
    private UserService userService;
    
    @Autowired
    private GroupMemberService groupMemberService;

    @PostMapping("/register")
    public ResponseEntity<RegisterUserResponseDTO> registerUser(@RequestBody RegisterUserRequestDTO request) {
        userService.registerUser(request);
      //  return ResponseEntity.ok(new RegisterUserResponseDTO("User registered successfully"));
        
        Long userId = userService.authenticateUser(request.getUserName(), request.getPassword());
	    
	        return ResponseEntity.ok(new RegisterUserResponseDTO("User registered successfully", userId));
    }
    
    @PostMapping("/authenticate")
    public ResponseEntity<AuthenticateUserResponseDTO> authenticateUser(@RequestBody AuthenticateUserRequestDTO request) {
        /*boolean isAuthenticated = userService.authenticateUser(request.getUserName(), request.getPassword());
        
        if (isAuthenticated) {
            return ResponseEntity.ok(new AuthenticateUserResponseDTO("Authentication successful"));
        } else {
            return ResponseEntity.status(401).body(new AuthenticateUserResponseDTO("Authentication failed. Please register first."));
        }*/
    	
    	  Long userId = userService.authenticateUser(request.getUserName(), request.getPassword());
    	    
    	    if (userId != null) {
    	        return ResponseEntity.ok(new AuthenticateUserResponseDTO("Authentication successful", userId));
    	    } else {
    	        return ResponseEntity.status(401).body(new AuthenticateUserResponseDTO("Authentication failed. Please register first."));
    	    }
    }
    
    @GetMapping("/{userId}/groups")
    public ResponseEntity<UserGroupsResponseDTO> getUserGroups(@PathVariable Long userId) {
        UserGroupsResponseDTO response = groupMemberService.getUserGroups(userId);
        return ResponseEntity.ok(response);
    }
}
