package com.godsend.controller;

import com.godsend.dto.MessageResponseDTO;
import com.godsend.dto.UserProfileRequestDTO;
import com.godsend.dto.UserProfileResponseDTO;
import com.godsend.service.UserProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;



@RestController
@CrossOrigin(origins = "http://localhost:4200", methods= {RequestMethod.GET, RequestMethod.POST})
@RequestMapping("/godsend/users")
public class UserProfileController {

    @Autowired
    private UserProfileService userProfileService;

    @PostMapping("/{id}/userprofile")
    public ResponseEntity<MessageResponseDTO> createUserProfile(@PathVariable("id") Long userId,
                                                                 @RequestBody UserProfileRequestDTO userProfileRequest) {
       userProfileService.createUserProfile(userId, userProfileRequest);
       return ResponseEntity.ok(new MessageResponseDTO("User Profile created successfully"));
    }
    
    
    @GetMapping("/{id}/userprofile")
    public ResponseEntity<UserProfileResponseDTO> getUserProfile(@PathVariable("id") Long userId) {
        UserProfileResponseDTO response = userProfileService.getUserProfile(userId);
        return ResponseEntity.ok(response);
    }

}
