package com.godsend.dto;

import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AddUserToGroupRequestDTO {


	  private Long userId;
	  private Date joinedDate;

}


