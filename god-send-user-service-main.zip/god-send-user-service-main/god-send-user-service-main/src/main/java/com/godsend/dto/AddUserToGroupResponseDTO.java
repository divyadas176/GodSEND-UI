package com.godsend.dto;

public class AddUserToGroupResponseDTO {
    private String message;

    // Constructor
    public AddUserToGroupResponseDTO(String message) {
        this.message = message;
    }

    // Getter
    public String getMessage() {
        return message;
    }
}