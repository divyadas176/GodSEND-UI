package com.godsend.dto;



import java.util.Date;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AllGroupDetailResponseDTO {
	/*  private Long groupId;
      private String groupName;
      private String groupDescription;
      private Long createdByUser;*/
	
	
	  private Long groupId;
	    private String groupName;
	    private String groupDescription;
	    private Long createdByUser;

	    private List<GroupPostDTO> groupPosts;

	    @Getter
	    @Setter
	    public static class GroupPostDTO {
	        private Long postId;
	        private String postContent;
	        private Date postAddedDate;
	        private Long postedByUser;
	        private List<GroupPostReplyDTO> postReplies;
	    }

	    @Getter
	    @Setter
	    public static class GroupPostReplyDTO {
	        private Long replyId;
	        private String replyContent;
	        private Date replyAddedDate;
	        private Long repliedByUser;
	    }
}
