package com.godsend.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuthenticateUserResponseDTO {
    private String message;
    private Long userId;
    
    
    public AuthenticateUserResponseDTO(String message, Long userId) {
        this.message = message;
        this.userId = userId;
    }


	public AuthenticateUserResponseDTO(String message) {
		 this.message = message;
		// TODO Auto-generated constructor stub
	}
}
