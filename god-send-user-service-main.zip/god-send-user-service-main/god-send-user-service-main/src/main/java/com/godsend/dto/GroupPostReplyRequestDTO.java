package com.godsend.dto;


import java.util.Date;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class GroupPostReplyRequestDTO {
	private Long userGroupPostId;
    private Long userId;
    private String reply;
    private Date replyAddeddate;
}