package com.godsend.dto;

import java.util.Date;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class GroupPostRequestDTO {
    private Long userGroupId;
    private Long userId;
    private String post;
    private Date postAddeddate;
}