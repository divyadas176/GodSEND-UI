package com.godsend.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RegisterUserResponseDTO {
    private String message;
    private Long userID;

    public RegisterUserResponseDTO(String message) {
        this.message = message;
    }
    
    public RegisterUserResponseDTO(String message, Long userID) {
    	this.userID = userID;
        this.message = message;
    }
}
