package com.godsend.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;


@Getter
@Setter
public class UserGroupDetailResponseDTO {
    private Long userGroupId;
    private String groupName;
    private String groupCategory;
    private String groupDescription;
    private Date groupCreatedDate;
   // private List<String> groupMembers; // Adjust according to your requirements

}
