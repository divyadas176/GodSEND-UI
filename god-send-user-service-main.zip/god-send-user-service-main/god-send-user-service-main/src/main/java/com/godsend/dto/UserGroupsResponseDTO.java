package com.godsend.dto;

import java.util.Date;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserGroupsResponseDTO {
    private Long userId;
    private UserProfileDTO userProfile;
    private List<GroupDTO> groups;

    // Getters and Setters
    @Getter
    @Setter
    public static class GroupDTO {
        private Long groupId;
        private String groupName;
        private String groupDescription;

        private List<GroupPostDTO> groupPosts;
        // Getters and Setters
    }
    
    @Getter
    @Setter
    public static class UserProfileDTO {
   	/* private String firstName;
   	    private String lastName;
   	    private String email;
   	    private String phoneNumber;
   	    private String gender;
   	    private String childName;
   	    private String category;*/
    	
    	 private Long userId; 
    	 	private String parentName;
    	    private String email;
    	    private String address;
    	   // private String phoneNumber;
    	    private String childName;
    	    private String childAge;
    	    private String ChildGender;
    	    private String diseaseCategory ;
   }
    
    @Getter
    @Setter
    public static class GroupPostDTO {
        private Long postId;
        private String postContent;
        private Date postAddedDate;
        private Long postedByUser;
        private List<GroupPostReplyDTO> postReplies;

        // Getters and Setters
    }
    
    
    @Getter
    @Setter
    public static class GroupPostReplyDTO {
        private Long replyId;
        private String replyContent;
        private Date replyAddedDate;
        private Long repliedByUser;

        // Getters and Setters
    }

}
