package com.godsend.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserProfileRequestDTO {
	
	    //private String firstName;
	    // private String lastName;
	 	private String parentName;
	    private String email;
	    private String address;
	   // private String phoneNumber;
	    private String childName;
	    private String childAge;
	    private String ChildGender;
	    private String diseaseCategory ;
	   
	    
}
