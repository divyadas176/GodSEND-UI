package com.godsend.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserProfileResponseDTO {
   /* private Long userId;  
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private String gender;
    private String childName;
    private String category;*/
	
    //private String firstName;
    // private String lastName;
	 private Long userId; 
 	private String parentName;
    private String email;
    private String address;
   // private String phoneNumber;
    private String childName;
    private String childAge;
    private String ChildGender;
    private String diseaseCategory ;


    // Default constructor
    public UserProfileResponseDTO() {
    }
}
