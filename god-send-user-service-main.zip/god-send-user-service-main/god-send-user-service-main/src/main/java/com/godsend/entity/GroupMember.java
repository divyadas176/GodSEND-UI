package com.godsend.entity;

import java.util.Date;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "group_members")
public class GroupMember {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="group_member_id")
    private Long groupMemberId;

    @ManyToOne
    @JoinColumn(name = "user_group_id", nullable = false)
    private UserGroups userGroup;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name="joined_date")
    private Date joinedDate;
}
