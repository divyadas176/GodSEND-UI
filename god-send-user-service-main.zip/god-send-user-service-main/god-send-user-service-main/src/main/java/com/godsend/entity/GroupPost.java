package com.godsend.entity;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "group_posts")
public class GroupPost {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="group_post_id")
    private Long groupPostId;

    @Column(name="post")
    private String post;  
    
    @Column(name="post_added_date")
    private Date postAddedDate;
    
    @ManyToOne
    @JoinColumn(name = "user_group_id", nullable = false)
    private UserGroups userGroup;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
    
    @OneToMany(mappedBy = "groupPost", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<GroupPostReply> groupPostReplies;
    
    
    public GroupPost() {}

    public GroupPost(UserGroups userGroup, User user, String post, Date postAddedDate) {
        this.userGroup = userGroup;
        this.user = user;
        this.post = post;
        this.postAddedDate = postAddedDate;
    }

}
