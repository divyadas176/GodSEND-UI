package com.godsend.entity;

import java.util.Date;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "group_post_replies")
public class GroupPostReply {
   

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="group_post_reply_id")
    private Long groupPostReplyId;

    @Column(name="reply")
    private String reply;  
    
    @Column(name="reply_added_date")
    private Date replyAddedDate;
    
    @ManyToOne
    @JoinColumn(name = "group_post_id", nullable = false)
    private GroupPost groupPost;

    @ManyToOne
    @JoinColumn(name = "reply_user_id", nullable = false)
    private User user;
    
    
    public GroupPostReply(GroupPost userGroupPosst, User user, String reply, Date replyAddedDate) {
		// TODO Auto-generated constructor stub
    	
    	   this.groupPost = userGroupPosst;
           this.reply = reply;
           this.user = user;
           this.replyAddedDate = replyAddedDate;
	} 
    
    public GroupPostReply() {
    }

    
}
    
