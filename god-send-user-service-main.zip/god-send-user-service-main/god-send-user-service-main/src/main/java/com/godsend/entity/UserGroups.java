package com.godsend.entity;

import java.util.Date;
import java.util.List;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "user_groups")
public class UserGroups {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="user_group_id")
    private Long userGroupId;  // Renamed for consistency

    @ManyToOne
    @JoinColumn(name = "created_user_id", nullable = false)
    private User createdUser;

    @Column(name="group_name")
    private String groupName;
    
    @Column(name="group_category")
    private String groupCategory;
    
    @Column(name="group_description")
    private String groupDescription;
    
    @Column(name="group_created_date")
    private Date groupCreatedDate;
    
    @ManyToMany(mappedBy = "joinedGroups")
    private List<User> groupMembers;
    
    @OneToMany(mappedBy = "userGroup", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<GroupPost> groupPosts;
}
