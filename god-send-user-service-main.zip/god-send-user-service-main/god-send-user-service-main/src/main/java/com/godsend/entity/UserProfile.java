package com.godsend.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "user_profile")
public class UserProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="user_profile_id")
    private Long userProfileId;

    @OneToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name="first_name")
    private String firstName;
    
    @Column(name="last_name")
    private String lastName;
    
    @Column(name="parent_name")
    private String parentName;
    
    @Column(name="email")
    private String email;
    
    @Column(name="phone_number")
    private String phoneNumber;
    
    @Column(name="child_gender")
    private String childGender;
    
    @Column(name="child_name")
    private String childName;
    
    @Column(name="child_age")
    private String childAge;
    
    @Column(name="address")
    private String address;
    
    @Column(name="category")
    private String diseaseCategory ;
}
