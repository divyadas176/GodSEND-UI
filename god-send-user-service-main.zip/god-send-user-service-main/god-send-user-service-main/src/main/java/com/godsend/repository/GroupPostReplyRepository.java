package com.godsend.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.godsend.entity.GroupPostReply;

public interface GroupPostReplyRepository extends JpaRepository<GroupPostReply, Long> {

}
