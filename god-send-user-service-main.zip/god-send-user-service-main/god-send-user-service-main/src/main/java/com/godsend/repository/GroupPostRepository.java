package com.godsend.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.godsend.entity.GroupPost;

public interface GroupPostRepository extends JpaRepository<GroupPost, Long> {


}
