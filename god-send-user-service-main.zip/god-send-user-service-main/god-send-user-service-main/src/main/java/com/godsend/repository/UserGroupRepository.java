package com.godsend.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.godsend.entity.User;
import com.godsend.entity.UserGroups;

@Repository
public interface UserGroupRepository extends JpaRepository<UserGroups, Long> {

    // Optional: Add custom query methods if needed
    // For example, find groups created by a specific user
    List<UserGroups> findByCreatedUser(User user);
    
    List<UserGroups> findAll();
       
}
