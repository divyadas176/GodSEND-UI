package com.godsend.repository;

import com.godsend.entity.User;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
	
	    boolean existsByUserNameAndPassword(String userName, String password);

		Optional<User> findByUserId(Long userId);
		
		 Optional<User> findByUserNameAndPassword(String userName, String password);
		
		
	}
