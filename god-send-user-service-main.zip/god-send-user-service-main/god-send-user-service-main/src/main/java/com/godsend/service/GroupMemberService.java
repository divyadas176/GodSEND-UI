package com.godsend.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.godsend.dto.GroupMemberResponseDTO;
import com.godsend.dto.UserGroupsResponseDTO;
import com.godsend.dto.UserGroupsResponseDTO.GroupPostDTO;
import com.godsend.dto.UserGroupsResponseDTO.GroupPostReplyDTO;
import com.godsend.dto.UserGroupsResponseDTO.UserProfileDTO;
import com.godsend.entity.GroupMember;
import com.godsend.entity.User;
import com.godsend.entity.UserGroups;
import com.godsend.entity.UserProfile;
import com.godsend.repository.GroupMemberRepository;
import com.godsend.repository.UserGroupRepository;
import com.godsend.repository.UserProfileRepository;
import com.godsend.repository.UserRepository;

@Service
public class GroupMemberService {

    @Autowired
    private GroupMemberRepository groupMemberRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserGroupRepository userGroupRepository;
    

    @Autowired
    private UserProfileRepository userProfileRepository;
    
    UserProfileDTO userProfileDTO ;

    public boolean addUserToGroup(Long userGroupId, Long userId, Date joinedDate) {
        Optional<User> userOptional = userRepository.findById(userId);
        Optional<UserGroups> userGroupOptional = userGroupRepository.findById(userGroupId);

        if (userOptional.isPresent() && userGroupOptional.isPresent()) {
            User user = userOptional.get();
            UserGroups userGroup = userGroupOptional.get();

            GroupMember groupMember = new GroupMember();
            groupMember.setUser(user);;
            groupMember.setUserGroup(userGroup);
            groupMember.setJoinedDate(joinedDate);
  

            groupMemberRepository.save(groupMember);
            return true;
        } else {
            return false;
        }
    }
    
    public List<GroupMemberResponseDTO> getGroupMembers(Long userGroupId) {
        List<GroupMember> groupMembers = groupMemberRepository.findByUserGroup_UserGroupId(userGroupId);

        return groupMembers.stream().map(member -> {
            GroupMemberResponseDTO dto = new GroupMemberResponseDTO();
            dto.setUserId(member.getUser().getUserId());
            dto.setUserName(member.getUser().getUserName());
            dto.setJoinedDate(member.getJoinedDate());
            return dto;
        }).collect(Collectors.toList());
    }
    
    
    public UserGroupsResponseDTO getUserGroups(Long userId) {
        // Get the user profile for the given userId
       Optional<UserProfile> optionalUserProfile = userProfileRepository.findByUser_UserId(userId);

        // Create a new response DTO
       UserGroupsResponseDTO response = new UserGroupsResponseDTO();
      response.setUserId(userId);

       if (optionalUserProfile.isPresent()) {
            UserProfile userProfile = optionalUserProfile.get();
            
            // Populate userProfileDTO in response
            UserGroupsResponseDTO.UserProfileDTO userProfileDTO = new UserGroupsResponseDTO.UserProfileDTO();
           // userProfileDTO.setFirstName(userProfile.getFirstName());
           // userProfileDTO.setLastName(userProfile.getLastName());
            userProfileDTO.setParentName(userProfile.getParentName());
            userProfileDTO.setEmail(userProfile.getEmail());
            userProfileDTO.setAddress(userProfile.getAddress());
            //userProfileDTO.setPhoneNumber(userProfile.getPhoneNumber());
            //userProfileDTO.setGender(userProfile.getChildGender());
            userProfileDTO.setChildGender(userProfile.getChildGender());
            userProfileDTO.setChildName(userProfile.getChildName());
            userProfileDTO.setChildAge(userProfile.getChildAge());
           // userProfileDTO.setCategory(userProfile.getCategory());
            userProfileDTO.setDiseaseCategory(userProfile.getDiseaseCategory());

                       
            response.setUserProfile(userProfileDTO);
        } else {
            // Handle case where userProfile is not found
            response.setUserProfile(null);
        }

        // Retrieve the groups the user belongs to
        List<UserGroups> userGroups = groupMemberRepository.findByUser_UserId(userId).stream()
            .map(GroupMember::getUserGroup)
            .collect(Collectors.toList());

        // Populate groups in response
        List<UserGroupsResponseDTO.GroupDTO> groupsDTO = userGroups.stream()
            .map(group -> {
                UserGroupsResponseDTO.GroupDTO groupDTO = new UserGroupsResponseDTO.GroupDTO();
                groupDTO.setGroupId(group.getUserGroupId());
                groupDTO.setGroupName(group.getGroupName());
                groupDTO.setGroupDescription(group.getGroupDescription());
                
                // Populate posts and replies
                List<GroupPostDTO> postsDTO = group.getGroupPosts().stream()
                    .map(post -> {
                        GroupPostDTO postDTO = new GroupPostDTO();
                        postDTO.setPostId(post.getGroupPostId());
                        postDTO.setPostContent(post.getPost());
                        postDTO.setPostAddedDate(post.getPostAddedDate());
                        postDTO.setPostedByUser(post.getUser().getUserId());

                        List<GroupPostReplyDTO> repliesDTO = post.getGroupPostReplies().stream()
                            .map(reply -> {
                                GroupPostReplyDTO replyDTO = new GroupPostReplyDTO();
                                replyDTO.setReplyId(reply.getGroupPostReplyId());
                                replyDTO.setReplyContent(reply.getReply());
                                replyDTO.setReplyAddedDate(reply.getReplyAddedDate());
                                replyDTO.setRepliedByUser(reply.getUser().getUserId());
                                return replyDTO;
                            }).collect(Collectors.toList());

                        postDTO.setPostReplies(repliesDTO);
                        return postDTO;
                    }).collect(Collectors.toList());

                groupDTO.setGroupPosts(postsDTO);
                return groupDTO;
            })
            .collect(Collectors.toList());

        response.setGroups(groupsDTO);

        return response;
        
       
    }

}
