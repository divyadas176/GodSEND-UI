package com.godsend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.godsend.dto.GroupPostReplyRequestDTO;
import com.godsend.entity.GroupPost;
import com.godsend.entity.GroupPostReply;
import com.godsend.entity.User;
import com.godsend.repository.GroupPostReplyRepository;
import com.godsend.repository.GroupPostRepository;
import com.godsend.repository.UserRepository;

@Service
public class GroupPostReplyService {

    @Autowired
    private GroupPostRepository groupPostRepository;
    
    @Autowired
    private GroupPostReplyRepository groupPostReplyRepository;

    @Autowired
    private UserRepository userRepository;

    public void createGroupPostReply(GroupPostReplyRequestDTO request) {
        // Fetch the user group and user
        GroupPost userGroupPosst = groupPostRepository.findById(request.getUserGroupPostId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid group ID"));
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid user ID"));

        // Create and save the group post
        GroupPostReply groupPostReply = new GroupPostReply(userGroupPosst, user, request.getReply(), request.getReplyAddeddate());
        groupPostReply = groupPostReplyRepository.save(groupPostReply);

        
    
    }
}
