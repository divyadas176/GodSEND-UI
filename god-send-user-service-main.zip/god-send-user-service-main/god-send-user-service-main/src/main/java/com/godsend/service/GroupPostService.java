package com.godsend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.godsend.dto.GroupPostRequestDTO;
import com.godsend.entity.GroupPost;
import com.godsend.entity.User;
import com.godsend.entity.UserGroups;
import com.godsend.repository.GroupPostRepository;
import com.godsend.repository.UserGroupRepository;
import com.godsend.repository.UserRepository;

@Service
public class GroupPostService {

    @Autowired
    private GroupPostRepository groupPostRepository;

    @Autowired
    private UserGroupRepository userGroupsRepository;

    @Autowired
    private UserRepository userRepository;

    public void createGroupPost(GroupPostRequestDTO request) {
        // Fetch the user group and user
        UserGroups userGroup = userGroupsRepository.findById(request.getUserGroupId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid group ID"));
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid user ID"));

        // Create and save the group post
        GroupPost groupPost = new GroupPost(userGroup, user, request.getPost(), request.getPostAddeddate());
        groupPost = groupPostRepository.save(groupPost);

    
    }
}
