package com.godsend.service;

import com.godsend.dto.AllGroupDetailResponseDTO;
import com.godsend.dto.AllGroupDetailResponseDTO.GroupPostDTO;
import com.godsend.dto.AllGroupDetailResponseDTO.GroupPostReplyDTO;
import com.godsend.dto.GroupCreationRequestDTO;
import com.godsend.dto.UserGroupDetailResponseDTO;
import com.godsend.entity.User;
import com.godsend.entity.UserGroups;
import com.godsend.repository.GroupRepository;
import com.godsend.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class GroupService {

    @Autowired
    private GroupRepository groupRepository;

    @Autowired
    private UserRepository userRepository;
    

    public void createGroup(GroupCreationRequestDTO requestDTO) {
        User user = userRepository.findById(requestDTO.getCreatedUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        UserGroups group = new UserGroups();
        group.setCreatedUser(user);
        group.setGroupName(requestDTO.getGroupName());
        group.setGroupCategory(requestDTO.getGroupCategory());
        group.setGroupDescription(requestDTO.getGroupDescription());
        group.setGroupCreatedDate(new Date());

        groupRepository.save(group);
    }


	public UserGroupDetailResponseDTO getGroupById(Long userGroupId) {
		
		  UserGroups userGroup = groupRepository.findById(userGroupId)
	                .orElseThrow(() -> new RuntimeException("Group not found"));
		
		UserGroupDetailResponseDTO groupDetailsResponseDTO = new UserGroupDetailResponseDTO();
		
		groupDetailsResponseDTO.setGroupCategory(userGroup.getGroupCategory());
		groupDetailsResponseDTO.setGroupCreatedDate(userGroup.getGroupCreatedDate());
		groupDetailsResponseDTO.setGroupDescription(userGroup.getGroupDescription());
		groupDetailsResponseDTO.setGroupName(userGroup.getGroupName());
		groupDetailsResponseDTO.setUserGroupId(userGroup.getUserGroupId());

		
		 return groupDetailsResponseDTO;
	}
       
	public List<AllGroupDetailResponseDTO> getAllGroups() {
      
	/*	List<UserGroups> userGroups = groupRepository.findAll();

        return userGroups.stream()
                .map(group -> {
                	AllGroupDetailResponseDTO groupDTO = new AllGroupDetailResponseDTO();
                    groupDTO.setGroupId(group.getUserGroupId());
                    groupDTO.setGroupName(group.getGroupName());
                    groupDTO.setGroupDescription(group.getGroupDescription());
                    groupDTO.setCreatedByUser(group.getCreatedUser().getUserId());
                    return groupDTO;
                })
                .collect(Collectors.toList());*/
		
		 List<UserGroups> userGroups = groupRepository.findAll();

	        return userGroups.stream()
	            .map(group -> {
	                AllGroupDetailResponseDTO groupDTO = new AllGroupDetailResponseDTO();
	                groupDTO.setGroupId(group.getUserGroupId());
	                groupDTO.setGroupName(group.getGroupName());
	                groupDTO.setGroupDescription(group.getGroupDescription());
	                groupDTO.setCreatedByUser(group.getCreatedUser().getUserId());

	                // Populate posts and replies
	                List<GroupPostDTO> postsDTO = group.getGroupPosts().stream()
	                    .map(post -> {
	                        GroupPostDTO postDTO = new GroupPostDTO();
	                        postDTO.setPostId(post.getGroupPostId());
	                        postDTO.setPostContent(post.getPost());
	                        postDTO.setPostAddedDate(post.getPostAddedDate());
	                        postDTO.setPostedByUser(post.getUser().getUserId());

	                        List<GroupPostReplyDTO> repliesDTO = post.getGroupPostReplies().stream()
	                            .map(reply -> {
	                                GroupPostReplyDTO replyDTO = new GroupPostReplyDTO();
	                                replyDTO.setReplyId(reply.getGroupPostReplyId());
	                                replyDTO.setReplyContent(reply.getReply());
	                                replyDTO.setReplyAddedDate(reply.getReplyAddedDate());
	                                replyDTO.setRepliedByUser(reply.getUser().getUserId());
	                                return replyDTO;
	                            }).collect(Collectors.toList());

	                        postDTO.setPostReplies(repliesDTO);
	                        return postDTO;
	                    }).collect(Collectors.toList());

	                groupDTO.setGroupPosts(postsDTO);
	                return groupDTO;
	            })
	            .collect(Collectors.toList());
	    
    }
}
