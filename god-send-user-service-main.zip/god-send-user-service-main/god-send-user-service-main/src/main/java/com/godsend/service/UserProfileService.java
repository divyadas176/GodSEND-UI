package com.godsend.service;

import com.godsend.dto.UserProfileRequestDTO;
import com.godsend.dto.UserProfileResponseDTO;
import com.godsend.entity.User;
import com.godsend.entity.UserProfile;
import com.godsend.repository.UserProfileRepository;
import com.godsend.repository.UserRepository;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserProfileService {

    @Autowired
    private UserProfileRepository userProfileRepository;

    @Autowired
    private UserRepository userRepository;

    public UserProfileResponseDTO createUserProfile(Long userId, UserProfileRequestDTO userProfileRequest) {
        UserProfileResponseDTO response = new UserProfileResponseDTO();

        // Find the user by ID
        User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));

        // Create a new UserProfile
        UserProfile userProfile = new UserProfile();
        userProfile.setUser(user);
        // userProfile.setFirstName(userProfileRequest.getFirstName());
        // userProfile.setLastName(userProfileRequest.getLastName());
        userProfile.setParentName(userProfileRequest.getParentName());
        userProfile.setEmail(userProfileRequest.getEmail());
        userProfile.setAddress(userProfileRequest.getAddress());
        // userProfile.setPhoneNumber(userProfileRequest.getPhoneNumber());
        userProfile.setChildGender(userProfileRequest.getChildGender());
        userProfile.setChildName(userProfileRequest.getChildName());
        userProfile.setChildAge(userProfileRequest.getChildAge());
        //userProfile.setCategory(userProfileRequest.getCategory());
        userProfile.setDiseaseCategory(userProfileRequest.getDiseaseCategory());
        

        // Save the UserProfile
        userProfileRepository.save(userProfile);

        return response;
    }
    
    public UserProfileResponseDTO getUserProfile(Long userId) {
       // User user = userRepository.findByUserId(userId).orElse(null);
        UserProfileResponseDTO response = new UserProfileResponseDTO();

        Optional<UserProfile> optionalUserProfile = userProfileRepository.findByUser_UserId(userId);


        UserProfile userProfile = optionalUserProfile.get();

        response.setUserId(userProfile.getUser().getUserId());  
       // response.setFirstName(userProfile.getFirstName());
       // response.setLastName(userProfile.getLastName());
        response.setParentName(userProfile.getParentName());
        response.setEmail(userProfile.getEmail());
      //  response.setPhoneNumber(userProfile.getPhoneNumber());
        response.setAddress(userProfile.getAddress());
      //  response.setGender(userProfile.getChildGender());
        response.setChildName(userProfile.getChildName());
        response.setChildAge(userProfile.getChildAge());
       // response.setCategory(userProfile.getCategory());
        response.setChildGender(userProfile.getChildGender());
        response.setDiseaseCategory(userProfile.getDiseaseCategory());
        return response;
    }


}
