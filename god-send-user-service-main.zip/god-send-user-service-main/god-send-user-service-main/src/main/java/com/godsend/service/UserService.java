package com.godsend.service;

import com.godsend.dto.RegisterUserRequestDTO;
import com.godsend.entity.User;
import com.godsend.repository.UserRepository;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public void registerUser(RegisterUserRequestDTO request) {
        User user = new User();
        user.setUserName(request.getUserName());
        user.setPassword(request.getPassword());
        userRepository.save(user);
    }
    
    public Long authenticateUser(String userName, String password) {
      //  return userRepository.existsByUserNameAndPassword(userName, password);
    	  Optional<User> user = userRepository.findByUserNameAndPassword(userName, password);
    	  return user.map(User::getUserId).orElse(null);
    }
}
